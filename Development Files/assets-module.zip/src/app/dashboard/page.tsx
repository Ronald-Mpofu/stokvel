'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import GroupsPage from './groups/page'
import ContributionsPage from './contributions/page'
import AssetsPage from './assets/page'

const TEAL = '#0F6E56'
const NAVY = '#0D2137'

const NAV_ITEMS = [
  { id: 'overview',      icon: '📊', label: 'Overview'       },
  { id: 'groups',        icon: '👥', label: 'Groups'         },
  { id: 'members',       icon: '👤', label: 'Members'        },
  { id: 'contributions', icon: '💳', label: 'Contributions'  },
  { id: 'payouts',       icon: '💰', label: 'Payouts'        },
  { id: 'assets',        icon: '🏗️',  label: 'Assets'        },
  { id: 'loans',         icon: '📋', label: 'Loans'          },
  { id: 'investments',   icon: '📈', label: 'Investments'    },
  { id: 'reports',       icon: '📄', label: 'Reports'        },
  { id: 'settings',      icon: '⚙️',  label: 'Settings'      },
]

const STATS = [
  { label: 'Active Groups',       value: '1',        sub: 'Harare Builders Circle', color: TEAL     },
  { label: 'Total Members',       value: '12',       sub: '10 active this cycle',   color: '#1A5EA8' },
  { label: 'Escrow Balance',      value: '$600',     sub: 'Held securely',          color: '#B45309' },
  { label: 'Monthly Pool',        value: '$1,000',   sub: '10 members × $100',      color: '#7C3AED' },
  { label: 'Payouts Completed',   value: '6',        sub: '4 remaining this cycle', color: TEAL     },
  { label: 'Platform Revenue',    value: '$120',     sub: '2% fee this month',      color: '#059669' },
  { label: 'Active Loans',        value: '0',        sub: 'No active loans',        color: '#DC2626' },
  { label: 'Insurance Pool',      value: '$90',      sub: '1.5% reserve',           color: '#B45309' },
]

const MEMBERS = [
  { name: 'Tariro Moyo',     pos: 1,  status: 'PAID',       score: 142, tier: 'GOLD'     },
  { name: 'Chiedza Mutasa',  pos: 6,  status: 'RECEIVED',   score: 118, tier: 'GOLD'     },
  { name: 'Farai Khumalo',   pos: 2,  status: 'PAID',       score: 134, tier: 'GOLD'     },
  { name: 'Simba Ndlovu',    pos: 4,  status: 'DUE',        score: 89,  tier: 'SILVER'   },
  { name: 'Paidamoyo Mhaka', pos: 7,  status: 'LATE',       score: 76,  tier: 'SILVER'   },
  { name: 'Rudo Zimuto',     pos: 3,  status: 'PAID',       score: 156, tier: 'PLATINUM' },
  { name: 'Kudzi Sithole',   pos: 5,  status: 'PAID',       score: 121, tier: 'GOLD'     },
  { name: 'Nomsa Dube',      pos: 8,  status: 'PAID',       score: 98,  tier: 'SILVER'   },
  { name: 'Muchaneta Choto', pos: 9,  status: 'PENDING',    score: 103, tier: 'GOLD'     },
  { name: 'Blessing Mlilo',  pos: 10, status: 'PENDING',    score: 87,  tier: 'SILVER'   },
]

const PAYOUT_SCHEDULE = [
  { month: 'Jan', name: 'Tariro Moyo',     status: 'DONE',    amount: '$1,000' },
  { month: 'Feb', name: 'Farai Khumalo',   status: 'DONE',    amount: '$1,000' },
  { month: 'Mar', name: 'Rudo Zimuto',     status: 'DONE',    amount: '$1,000' },
  { month: 'Apr', name: 'Simba Ndlovu',    status: 'DONE',    amount: '$1,000' },
  { month: 'May', name: 'Kudzi Sithole',   status: 'DONE',    amount: '$1,000' },
  { month: 'Jun', name: 'Chiedza Mutasa',  status: 'CURRENT', amount: '$1,000' },
  { month: 'Jul', name: 'Paidamoyo Mhaka', status: 'NEXT',   amount: '$1,000' },
  { month: 'Aug', name: 'Nomsa Dube',      status: 'FUTURE',  amount: '$1,000' },
  { month: 'Sep', name: 'Muchaneta Choto', status: 'FUTURE',  amount: '$1,000' },
  { month: 'Oct', name: 'Blessing Mlilo',  status: 'FUTURE',  amount: '$1,000' },
]

function statusPill(status: string) {
  const map: Record<string, [string, string]> = {
    PAID:     ['#DCFCE7', '#166534'],
    RECEIVED: ['#DBEAFE', '#1E40AF'],
    DUE:      ['#FEF9C3', '#854D0E'],
    LATE:     ['#FEE2E2', '#991B1B'],
    PENDING:  ['#F1F5F9', '#475569'],
  }
  const [bg, color] = map[status] || ['#F1F5F9', '#475569']
  return (
    <span style={{
      background: bg, color, fontSize: '11px', fontWeight: '600',
      padding: '2px 8px', borderRadius: '999px',
    }}>{status}</span>
  )
}

function tierBadge(tier: string) {
  const map: Record<string, [string, string]> = {
    PLATINUM: ['#E9D5FF', '#5B21B6'],
    GOLD:     ['#FEF3C7', '#92400E'],
    SILVER:   ['#F1F5F9', '#475569'],
    BRONZE:   ['#FEE2E2', '#7F1D1D'],
  }
  const [bg, color] = map[tier] || ['#F1F5F9', '#475569']
  return (
    <span style={{
      background: bg, color, fontSize: '10px', fontWeight: '600',
      padding: '2px 6px', borderRadius: '4px',
    }}>{tier}</span>
  )
}

export default function Dashboard() {
  const router = useRouter()
  const [active, setActive] = useState('overview')
  const [sidebarOpen, setSidebarOpen] = useState(true)
  const [user, setUser] = useState({ name: 'Administrator', role: 'SYSTEM_ADMIN' })

  function handleLogout() {
    document.cookie = 'access_token=; Max-Age=0; path=/'
    document.cookie = 'refresh_token=; Max-Age=0; path=/'
    router.push('/login')
  }

  const initials = user.name.split(' ').map(n => n[0]).join('').slice(0, 2)

  return (
    <div style={{ display: 'flex', height: '100vh', fontFamily: 'system-ui, sans-serif', background: '#F8FAFC' }}>

      {/* ── Sidebar ─────────────────────────────────────────── */}
      <div style={{
        width: sidebarOpen ? '220px' : '60px',
        background: NAVY,
        display: 'flex', flexDirection: 'column',
        transition: 'width 0.2s',
        flexShrink: 0,
        overflow: 'hidden',
      }}>
        {/* Brand */}
        <div style={{
          padding: '20px 16px 16px',
          borderBottom: '1px solid rgba(255,255,255,0.1)',
          display: 'flex', alignItems: 'center', gap: '10px',
        }}>
          <div style={{
            width: '32px', height: '32px', background: TEAL,
            borderRadius: '8px', display: 'flex', alignItems: 'center',
            justifyContent: 'center', fontSize: '16px', flexShrink: 0,
          }}>🔄</div>
          {sidebarOpen && (
            <div>
              <div style={{ color: 'white', fontSize: '13px', fontWeight: '700' }}>Stokvel</div>
              <div style={{ color: '#9FE1CB', fontSize: '10px' }}>Platform</div>
            </div>
          )}
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            style={{
              marginLeft: 'auto', background: 'none', border: 'none',
              color: '#9CA3AF', cursor: 'pointer', fontSize: '18px', flexShrink: 0,
            }}
          >
            {sidebarOpen ? '◀' : '▶'}
          </button>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: '8px 0', overflowY: 'auto' }}>
          {NAV_ITEMS.map(item => (
            <button
              key={item.id}
              onClick={() => setActive(item.id)}
              style={{
                width: '100%', display: 'flex', alignItems: 'center', gap: '10px',
                padding: '10px 16px', background: active === item.id ? 'rgba(255,255,255,0.1)' : 'none',
                border: 'none', borderLeft: active === item.id ? `3px solid ${TEAL}` : '3px solid transparent',
                color: active === item.id ? 'white' : '#94A3B8',
                cursor: 'pointer', fontSize: '13px', textAlign: 'left',
                transition: 'all 0.15s',
              }}
            >
              <span style={{ fontSize: '16px', flexShrink: 0 }}>{item.icon}</span>
              {sidebarOpen && <span style={{ fontWeight: active === item.id ? '500' : '400' }}>{item.label}</span>}
            </button>
          ))}
        </nav>

        {/* User */}
        <div style={{
          padding: '12px 16px',
          borderTop: '1px solid rgba(255,255,255,0.1)',
          display: 'flex', alignItems: 'center', gap: '10px',
        }}>
          <div style={{
            width: '32px', height: '32px', borderRadius: '50%',
            background: TEAL, display: 'flex', alignItems: 'center',
            justifyContent: 'center', color: 'white',
            fontSize: '12px', fontWeight: '600', flexShrink: 0,
          }}>{initials}</div>
          {sidebarOpen && (
            <>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ color: 'white', fontSize: '12px', fontWeight: '500', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{user.name}</div>
                <div style={{ color: '#9CA3AF', fontSize: '10px' }}>{user.role.replace('_', ' ')}</div>
              </div>
              <button onClick={handleLogout} style={{ background: 'none', border: 'none', color: '#9CA3AF', cursor: 'pointer', fontSize: '16px' }} title="Logout">↩</button>
            </>
          )}
        </div>
      </div>

      {/* ── Main ────────────────────────────────────────────── */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        {/* Topbar */}
        <div style={{
          background: 'white', padding: '14px 24px',
          borderBottom: '1px solid #E2E8F0',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          flexShrink: 0,
        }}>
          <div>
            <h1 style={{ fontSize: '18px', fontWeight: '600', color: NAVY, margin: 0 }}>
              {NAV_ITEMS.find(n => n.id === active)?.icon} {NAV_ITEMS.find(n => n.id === active)?.label}
            </h1>
            <p style={{ fontSize: '12px', color: '#64748B', margin: '2px 0 0' }}>
              Harare Builders Circle · Cycle 1 · Month 6 of 10
            </p>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <span style={{
              background: '#DCFCE7', color: '#166534',
              fontSize: '12px', padding: '4px 10px', borderRadius: '999px', fontWeight: '500',
            }}>● Live</span>
            <span style={{ fontSize: '12px', color: '#64748B' }}>
              {new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
            </span>
          </div>
        </div>

        {/* Page content */}
        <div style={{ flex: 1, overflow: 'auto', padding: '24px' }}>
          {active === 'overview' && <OverviewPage />}
          {active === 'groups' && <GroupsPage />}
          {active === 'contributions' && <ContributionsPage />}
          {active === 'assets' && <AssetsPage />}
          {active === 'members' && <MembersPage />}
          {active === 'payouts' && <PayoutsPage />}
          {active !== 'overview' && active !== 'members' && active !== 'payouts' && (
            <ComingSoon page={NAV_ITEMS.find(n => n.id === active)?.label || ''} />
          )}
        </div>
      </div>
    </div>
  )
}

// ── Overview Page ─────────────────────────────────────────────
function OverviewPage() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>

      {/* Stats grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '12px' }}>
        {STATS.map(s => (
          <div key={s.label} style={{
            background: 'white', borderRadius: '12px', padding: '16px',
            border: '1px solid #E2E8F0',
          }}>
            <div style={{ fontSize: '11px', color: '#64748B', marginBottom: '6px' }}>{s.label}</div>
            <div style={{ fontSize: '24px', fontWeight: '700', color: s.color }}>{s.value}</div>
            <div style={{ fontSize: '11px', color: '#94A3B8', marginTop: '4px' }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Two column */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '16px' }}>

        {/* Payout progress */}
        <div style={{ background: 'white', borderRadius: '12px', padding: '20px', border: '1px solid #E2E8F0' }}>
          <h3 style={{ fontSize: '14px', fontWeight: '600', color: NAVY, margin: '0 0 16px' }}>
            📅 Payout Schedule — Cycle 1
          </h3>
          {PAYOUT_SCHEDULE.map(p => (
            <div key={p.month} style={{
              display: 'flex', alignItems: 'center', gap: '10px',
              padding: '7px 0', borderBottom: '1px solid #F1F5F9',
            }}>
              <span style={{ fontSize: '11px', color: '#94A3B8', width: '28px' }}>{p.month}</span>
              <span style={{
                fontSize: '12px', color: p.status === 'CURRENT' ? TEAL : '#374151',
                fontWeight: p.status === 'CURRENT' ? '600' : '400', flex: 1,
              }}>{p.name}</span>
              <div style={{
                flex: 1, height: '6px', background: '#F1F5F9',
                borderRadius: '3px', overflow: 'hidden',
              }}>
                <div style={{
                  height: '100%', borderRadius: '3px',
                  width: p.status === 'DONE' ? '100%' : p.status === 'CURRENT' ? '60%' : '0%',
                  background: p.status === 'DONE' ? '#9FE1CB' : p.status === 'CURRENT' ? TEAL : 'transparent',
                }} />
              </div>
              <span style={{
                fontSize: '11px',
                color: p.status === 'DONE' ? TEAL : p.status === 'CURRENT' ? TEAL : '#94A3B8',
                width: '40px', textAlign: 'right',
              }}>
                {p.status === 'DONE' ? '✓' : p.status === 'CURRENT' ? 'Live' : p.amount}
              </span>
            </div>
          ))}
        </div>

        {/* Activity */}
        <div style={{ background: 'white', borderRadius: '12px', padding: '20px', border: '1px solid #E2E8F0' }}>
          <h3 style={{ fontSize: '14px', fontWeight: '600', color: NAVY, margin: '0 0 16px' }}>
            ⚡ Recent Activity
          </h3>
          {[
            { icon: '✅', text: 'Payout $1,000 released to C. Mutasa', time: '2 min ago', color: '#DCFCE7' },
            { icon: '💳', text: 'Pre-escrow $200 collected from C. Mutasa', time: '2 min ago', color: '#DBEAFE' },
            { icon: '⚠️', text: 'P. Mhaka payment retry #2 failed', time: '1 hr ago', color: '#FEF9C3' },
            { icon: '👤', text: 'New group Byo Savers created', time: '3 hrs ago', color: '#DBEAFE' },
            { icon: '💰', text: 'Kudzi Sithole contribution received', time: 'Yesterday', color: '#DCFCE7' },
            { icon: '📋', text: 'Monthly statement generated', time: 'Yesterday', color: '#F1F5F9' },
          ].map((a, i) => (
            <div key={i} style={{ display: 'flex', gap: '10px', marginBottom: '12px' }}>
              <div style={{
                width: '28px', height: '28px', borderRadius: '50%',
                background: a.color, display: 'flex', alignItems: 'center',
                justifyContent: 'center', fontSize: '12px', flexShrink: 0,
              }}>{a.icon}</div>
              <div>
                <div style={{ fontSize: '12px', color: '#374151' }}>{a.text}</div>
                <div style={{ fontSize: '11px', color: '#94A3B8', marginTop: '2px' }}>{a.time}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Escrow health */}
      <div style={{ background: 'white', borderRadius: '12px', padding: '20px', border: '1px solid #E2E8F0' }}>
        <h3 style={{ fontSize: '14px', fontWeight: '600', color: NAVY, margin: '0 0 16px' }}>
          🏦 Escrow Health
        </h3>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
          {[
            { label: 'Total Collected', value: '$6,000', note: '6 months × $1,000' },
            { label: 'Paid Out', value: '$5,000', note: '5 completed payouts' },
            { label: 'Held in Escrow', value: '$600', note: 'Current balance' },
            { label: 'Insurance Pool', value: '$90', note: '1.5% reserve' },
          ].map(item => (
            <div key={item.label} style={{
              background: '#F8FAFC', borderRadius: '8px',
              padding: '14px', border: '1px solid #E2E8F0',
            }}>
              <div style={{ fontSize: '11px', color: '#64748B' }}>{item.label}</div>
              <div style={{ fontSize: '20px', fontWeight: '700', color: TEAL, margin: '4px 0' }}>{item.value}</div>
              <div style={{ fontSize: '11px', color: '#94A3B8' }}>{item.note}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// ── Members Page ──────────────────────────────────────────────
function MembersPage() {
  const [search, setSearch] = useState('')
  const filtered = MEMBERS.filter(m =>
    m.name.toLowerCase().includes(search.toLowerCase())
  )
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <input
          placeholder="Search members..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{
            padding: '8px 14px', border: '1.5px solid #E2E8F0',
            borderRadius: '8px', fontSize: '13px', width: '280px', outline: 'none',
          }}
        />
        <button style={{
          background: TEAL, color: 'white', border: 'none',
          borderRadius: '8px', padding: '8px 16px', fontSize: '13px',
          fontWeight: '500', cursor: 'pointer',
        }}>+ Invite Member</button>
      </div>

      <div style={{ background: 'white', borderRadius: '12px', border: '1px solid #E2E8F0', overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: '#F8FAFC' }}>
              {['Member', 'Position', 'Tier', 'Score', 'Status', 'Contributed', 'Action'].map(h => (
                <th key={h} style={{
                  padding: '12px 16px', textAlign: 'left',
                  fontSize: '11px', fontWeight: '600', color: '#64748B',
                  borderBottom: '1px solid #E2E8F0', textTransform: 'uppercase',
                }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((m, i) => (
              <tr key={m.name} style={{ borderBottom: '1px solid #F1F5F9' }}>
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                    <div style={{
                      width: '32px', height: '32px', borderRadius: '50%',
                      background: '#E1F5EE', color: TEAL,
                      display: 'flex', alignItems: 'center', justifyContent: 'center',
                      fontSize: '11px', fontWeight: '600',
                    }}>
                      {m.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <span style={{ fontSize: '13px', fontWeight: '500', color: '#1E293B' }}>{m.name}</span>
                  </div>
                </td>
                <td style={{ padding: '12px 16px', fontSize: '13px', color: '#374151' }}>#{m.pos}</td>
                <td style={{ padding: '12px 16px' }}>{tierBadge(m.tier)}</td>
                <td style={{ padding: '12px 16px', fontSize: '13px', color: TEAL, fontWeight: '600' }}>{m.score}</td>
                <td style={{ padding: '12px 16px' }}>{statusPill(m.status)}</td>
                <td style={{ padding: '12px 16px', fontSize: '13px', color: '#374151' }}>${(m.pos * 100).toLocaleString()}</td>
                <td style={{ padding: '12px 16px' }}>
                  <button style={{
                    background: '#F1F5F9', border: 'none', borderRadius: '6px',
                    padding: '4px 10px', fontSize: '11px', cursor: 'pointer', color: '#475569',
                  }}>View</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ── Payouts Page ──────────────────────────────────────────────
function PayoutsPage() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '12px' }}>
        {[
          { label: 'Completed Payouts', value: '6', color: TEAL },
          { label: 'Remaining', value: '4', color: '#1A5EA8' },
          { label: 'Next Payout', value: 'Aug 1', color: '#B45309' },
        ].map(s => (
          <div key={s.label} style={{
            background: 'white', borderRadius: '12px',
            padding: '20px', border: '1px solid #E2E8F0',
          }}>
            <div style={{ fontSize: '12px', color: '#64748B' }}>{s.label}</div>
            <div style={{ fontSize: '28px', fontWeight: '700', color: s.color, marginTop: '6px' }}>{s.value}</div>
          </div>
        ))}
      </div>

      <div style={{ background: 'white', borderRadius: '12px', border: '1px solid #E2E8F0', overflow: 'hidden' }}>
        <div style={{ padding: '16px 20px', borderBottom: '1px solid #E2E8F0' }}>
          <h3 style={{ fontSize: '14px', fontWeight: '600', color: NAVY, margin: 0 }}>Full Payout Schedule</h3>
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ background: '#F8FAFC' }}>
              {['Month', 'Recipient', 'Amount', 'Date', 'Status', 'Gates', 'Action'].map(h => (
                <th key={h} style={{
                  padding: '10px 16px', textAlign: 'left',
                  fontSize: '11px', fontWeight: '600', color: '#64748B',
                  borderBottom: '1px solid #E2E8F0', textTransform: 'uppercase',
                }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {PAYOUT_SCHEDULE.map((p, i) => (
              <tr key={p.month} style={{
                borderBottom: '1px solid #F1F5F9',
                background: p.status === 'CURRENT' ? '#F0FDF4' : 'white',
              }}>
                <td style={{ padding: '12px 16px', fontSize: '13px', color: '#64748B' }}>{p.month} 2025</td>
                <td style={{ padding: '12px 16px', fontSize: '13px', fontWeight: p.status === 'CURRENT' ? '600' : '400', color: p.status === 'CURRENT' ? TEAL : '#374151' }}>{p.name}</td>
                <td style={{ padding: '12px 16px', fontSize: '13px', fontWeight: '600', color: '#1E293B' }}>{p.amount}</td>
                <td style={{ padding: '12px 16px', fontSize: '12px', color: '#64748B' }}>{`${i + 1} ${p.month} 2025`}</td>
                <td style={{ padding: '12px 16px' }}>
                  <span style={{
                    fontSize: '11px', fontWeight: '600', padding: '2px 8px', borderRadius: '999px',
                    background: p.status === 'DONE' ? '#DCFCE7' : p.status === 'CURRENT' ? '#BBF7D0' : '#F1F5F9',
                    color: p.status === 'DONE' ? '#166534' : p.status === 'CURRENT' ? '#166534' : '#64748B',
                  }}>
                    {p.status === 'DONE' ? '✓ Completed' : p.status === 'CURRENT' ? '⚡ Processing' : '⏳ Scheduled'}
                  </span>
                </td>
                <td style={{ padding: '12px 16px' }}>
                  {p.status === 'DONE' ? (
                    <span style={{ fontSize: '12px', color: TEAL }}>✓✓✓✓</span>
                  ) : p.status === 'CURRENT' ? (
                    <span style={{ fontSize: '12px', color: '#B45309' }}>3/4 passed</span>
                  ) : (
                    <span style={{ fontSize: '12px', color: '#94A3B8' }}>Pending</span>
                  )}
                </td>
                <td style={{ padding: '12px 16px' }}>
                  {p.status === 'CURRENT' && (
                    <button style={{
                      background: TEAL, color: 'white', border: 'none',
                      borderRadius: '6px', padding: '5px 12px',
                      fontSize: '11px', cursor: 'pointer', fontWeight: '500',
                    }}>Release</button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ── Coming Soon ───────────────────────────────────────────────
function ComingSoon({ page }: { page: string }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column',
      alignItems: 'center', justifyContent: 'center',
      height: '60vh', textAlign: 'center',
    }}>
      <div style={{ fontSize: '64px', marginBottom: '16px' }}>🚧</div>
      <h2 style={{ fontSize: '20px', fontWeight: '600', color: NAVY, margin: '0 0 8px' }}>
        {page} — Coming Next
      </h2>
      <p style={{ color: '#64748B', fontSize: '14px', maxWidth: '400px' }}>
        This module is being built. The database tables and API endpoints are ready —
        the UI is next in our build sequence.
      </p>
      <div style={{
        marginTop: '20px', background: '#F0FDF4', borderRadius: '8px',
        padding: '12px 20px', border: '1px solid #BBF7D0',
        fontSize: '13px', color: '#166534',
      }}>
        ✅ Database ready &nbsp;·&nbsp; ✅ API ready &nbsp;·&nbsp; 🔲 UI in progress
      </div>
    </div>
  )
}
